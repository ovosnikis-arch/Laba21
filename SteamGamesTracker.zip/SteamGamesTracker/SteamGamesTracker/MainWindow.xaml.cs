﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace SteamGamesTracker
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
      
            private ObservableCollection<GameItem> _allGames;
            private readonly string _saveFilePath = "games_data.txt";

            public MainWindow()
            {
                InitializeComponent();
                _allGames = new ObservableCollection<GameItem>();
            LoadData();
                ApplyFilter();
            }


            private void BtnAdd_Click(object sender, RoutedEventArgs e)
            {
                string name = TxtGameName.Text.Trim();
                if (string.IsNullOrEmpty(name))
                {
                    MessageBox.Show("Введите название игры!", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                    return;
                }

                bool isCompleted = CmbStatus.SelectedIndex == 1;

                _allGames.Add(new GameItem { Name = name, IsCompleted = isCompleted });

                TxtGameName.Clear();
                CmbStatus.SelectedIndex = 0;
                ApplyFilter();
            }

            private void BtnDelete_Click(object sender, RoutedEventArgs e)
            {
                if (GamesList.SelectedItem is GameItem selectedGame)
                {
                    _allGames.Remove(selectedGame);
                    ApplyFilter();
                }
                else
                {
                    MessageBox.Show("Выберите игру для удаления.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }

            private void BtnChangeStatus_Click(object sender, RoutedEventArgs e)
            {
                if (GamesList.SelectedItem is GameItem selectedGame)
                {
                    selectedGame.IsCompleted = !selectedGame.IsCompleted;
                    ApplyFilter(); 
                }
                else
                {
                    MessageBox.Show("Выберите игру для изменения статуса.", "Внимание", MessageBoxButton.OK, MessageBoxImage.Information);
                }
            }

            private void BtnFilter_Click(object sender, RoutedEventArgs e)
            {
                ApplyFilter();
            }

            private void BtnSave_Click(object sender, RoutedEventArgs e)
            {
                try
                {
                    var lines = _allGames.Select(g => $"{g.Name}|{g.IsCompleted}");
                    File.WriteAllLines(_saveFilePath, lines);
                    MessageBox.Show("Данные успешно сохранены!", "Сохранение", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при сохранении: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }

            private void ApplyFilter()
            {
                if (RbCompleted.IsChecked == true)
                {
                    GamesList.ItemsSource = new ObservableCollection<GameItem>(_allGames.Where(g => g.IsCompleted));
                }
                else if (RbNotCompleted.IsChecked == true)
                {
                    GamesList.ItemsSource = new ObservableCollection<GameItem>(_allGames.Where(g => !g.IsCompleted));
                }
                else
                {
                    GamesList.ItemsSource = _allGames;
                }
            }

            private void LoadData()
            {
                if (File.Exists(_saveFilePath))
                {
                    try
                    {
                        string[] lines = File.ReadAllLines(_saveFilePath);
                        foreach (var line in lines)
                        {
                            var parts = line.Split('|');
                            if (parts.Length == 2 && bool.TryParse(parts[1], out bool isCompleted))
                            {
                                _allGames.Add(new GameItem { Name = parts[0], IsCompleted = isCompleted });
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка при загрузке: {ex.Message}", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
        }

        public class GameItem : INotifyPropertyChanged
        {
            private string _name;
            private bool _isCompleted;

            public string Name
            {
                get => _name;
                set { _name = value; OnPropertyChanged(nameof(Name)); }
            }

            public bool IsCompleted
            {
                get => _isCompleted;
                set
                {
                    _isCompleted = value;
                    OnPropertyChanged(nameof(IsCompleted));
                    OnPropertyChanged(nameof(StatusColor));
                }
            }
            public Brush StatusColor => IsCompleted ? Brushes.ForestGreen : Brushes.Red;

            public event PropertyChangedEventHandler PropertyChanged;
            protected void OnPropertyChanged(string propertyName)
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }