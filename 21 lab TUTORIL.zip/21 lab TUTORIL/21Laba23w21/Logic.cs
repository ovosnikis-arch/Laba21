﻿using _21Laba23w21;
using _21Laba23w21.Domain;
using GalaSoft.MvvmLight.Command;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace _21Laba23w21
{
    public class Logic : INotifyPropertyChanged
    {
        public ObservableCollection<Teacher> Teachers { get; set; }
        public ObservableCollection<Institute> Institutes { get; set; }
        public ObservableCollection<Service> Services { get; set; }
        public ObservableCollection<TopService> TopServices { get; set; }

        private Teacher _newTeacher;
        public Teacher NewTeacher
        {
            get => _newTeacher;
            set
            {
                _newTeacher = value;
                OnPropertyChanged();
            }
        }

        private Teacher _selectedTeacher;
        public Teacher SelectedTeacher
        {
            get => _selectedTeacher;
            set
            {
                _selectedTeacher = value;
                OnPropertyChanged();
            }
        }

        public RelayCommand AddTeacherCommand { get; set; }
        public RelayCommand GetTopServiceCommand { get; set; }
        public RelayCommand DeleteTeacherCommand { get; set; }
        public RelayCommand ChangeInstituteCommand { get; set; }

        public Logic()
        {
            // Инициализация институтов
            Institutes = new ObservableCollection<Institute>
            {
                new Institute { Name = "ИКИТ" },
                new Institute { Name = "Гуманитарный" },
                new Institute { Name = "Институт спорта" }
            };

            // Инициализация сервисов
            Services = new ObservableCollection<Service>
            {
                new Service { Name = "Zoom" },
                new Service { Name = "Discord" },
                new Service { Name = "Teams" }
            };

            Teachers = new ObservableCollection<Teacher>();
            TopServices = new ObservableCollection<TopService>();

            // ВАЖНО: Инициализируем NewTeacher
            NewTeacher = new Teacher();

            // Инициализация команд
            AddTeacherCommand = new RelayCommand(AddTeacher);
            GetTopServiceCommand = new RelayCommand(GetTopService);
            DeleteTeacherCommand = new RelayCommand(DeleteTeacher);
            ChangeInstituteCommand = new RelayCommand(ChangeInstitute);

            // Добавляем тестовые данные
            Teachers.Add(new Teacher
            {
                FullName = "Иванов Иван Иванович",
                Institute = Institutes[0],
                Service = Services[0]
            });
            Teachers.Add(new Teacher
            {
                FullName = "Петров Петр Петрович",
                Institute = Institutes[1],
                Service = Services[1]
            });
            Teachers.Add(new Teacher
            {
                FullName = "Сидоров Сидор Сидорович",
                Institute = Institutes[2],
                Service = Services[0]
            });
        }

        private void AddTeacher()
        {
            // Проверяем, что NewTeacher не null и ФИО заполнено
            if (NewTeacher == null)
            {
                NewTeacher = new Teacher();
                return;
            }

            if (string.IsNullOrWhiteSpace(NewTeacher.FullName))
            {
                System.Windows.MessageBox.Show("Введите ФИО преподавателя!");
                return;
            }

            if (NewTeacher.Institute == null)
            {
                System.Windows.MessageBox.Show("Выберите институт!");
                return;
            }

            if (NewTeacher.Service == null)
            {
                System.Windows.MessageBox.Show("Выберите сервис!");
                return;
            }

            // Создаём нового преподавателя
            var teacher = new Teacher
            {
                FullName = NewTeacher.FullName.GetShortName(),
                Institute = NewTeacher.Institute,
                Service = NewTeacher.Service
            };

            Teachers.Add(teacher);

            // ВАЖНО: Создаём НОВЫЙ объект NewTeacher, чтобы очистить поля
            NewTeacher = new Teacher();

            // Сообщаем об изменении свойства
            OnPropertyChanged(nameof(NewTeacher));
        }

        private void GetTopService()
        {
            var topServices = Teachers
                .Where(t => t.Service != null)
                .GroupBy(t => t.Service.Name)
                .Select(g => new TopService
                {
                    ServiceName = g.Key,
                    Count = g.Count()
                })
                .OrderByDescending(t => t.Count)
                .Take(3)
                .ToList();

            TopServices.Clear();
            foreach (var service in topServices)
            {
                TopServices.Add(service);
            }

            OnPropertyChanged(nameof(TopServices));
        }

        private void DeleteTeacher()
        {
            if (SelectedTeacher != null)
            {
                Teachers.Remove(SelectedTeacher);
                SelectedTeacher = null;
            }
            else
            {
                System.Windows.MessageBox.Show("Выберите преподавателя для удаления!");
            }
        }

        private void ChangeInstitute()
        {
            if (SelectedTeacher == null)
            {
                System.Windows.MessageBox.Show("Выберите преподавателя!");
                return;
            }

            if (SelectedTeacher.Institute == null)
            {
                System.Windows.MessageBox.Show("У преподавателя не выбран институт!");
                return;
            }

            var currentIndex = Institutes.IndexOf(SelectedTeacher.Institute);
            var nextIndex = (currentIndex + 1) % Institutes.Count;
            SelectedTeacher.Institute = Institutes[nextIndex];
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}