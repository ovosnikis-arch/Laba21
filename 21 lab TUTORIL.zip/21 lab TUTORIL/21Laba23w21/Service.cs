﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21Laba23w21.Domain
{
    public class Service
    {
        public string Name { get; set; }
    }
}