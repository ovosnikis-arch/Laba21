﻿using _21Laba23w21.Domain;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace _21Laba23w21
{
    public class Teacher : INotifyPropertyChanged
    {
        private string _fullName;
        private Institute _institute;
        private Service _service;

        public string FullName
        {
            get => _fullName;
            set
            {
                _fullName = value;
                OnPropertyChanged();
            }
        }

        public Institute Institute
        {
            get => _institute;
            set
            {
                _institute = value;
                OnPropertyChanged();
            }
        }

        public Service Service
        {
            get => _service;
            set
            {
                _service = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}