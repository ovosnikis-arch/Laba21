﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;
using System.Windows.Media;

namespace _21Laba23w21
{
    public class ServiceToColorConverter : IValueConverter
    {
        private string status;
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            status = value.ToString();
            if (status.Equals("Discord"))
            {
                return Brushes.DarkGray;
            }
            if (status.Equals("Zoom"))
            {
                return Brushes.DarkGray;
            }
            if (status.Equals("WebinarSFU"))
            {
                return Brushes.DarkGray;
            }
            return Brushes.White;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
