﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21Laba23w21
{
    public static class NameHelper
    {
        public static string GetShortName(this string fullName)
        {
            if (string.IsNullOrEmpty(fullName)) return fullName;

            var parts = fullName.Split(' ');
            if (parts.Length >= 3)
            {
                return $"{parts[0]} {parts[1][0]}.{parts[2][0]}.";
            }
            return fullName;
        }
    }
}