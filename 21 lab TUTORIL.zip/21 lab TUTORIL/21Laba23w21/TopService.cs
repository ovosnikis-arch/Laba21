﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _21Laba23w21
{
    public class TopService
    {
        public string ServiceName { get; set; }
        public int Count { get; set; }
    }
}